# AMIS — Phase 1

AMIS (Autonomous Market & Intelligence System) Phase 1 is the executable foundation for opportunity intelligence. It provides a typed opportunity contract, deterministic expected-value scoring, configurable screening/risk gates, authenticated API access, persistence, migrations, and automated tests.

## Scope

Phase 1 deliberately does **not** execute trades or commercial transactions. `application.allow_execution` is false and no execution adapter exists in this phase. The output of the current decision layer is `CANDIDATE` or `NO_ACTION`.

## Architecture

```text
Client
  |
  v
FastAPI API -- API-key auth -- rate limiter
  |
  v
OpportunityService
  |---- deterministic EV scorer
  |---- composite opportunity scorer
  |---- central risk/screening gate
  |
  v
SQLAlchemy -> SQLite (local/test) or PostgreSQL (deployment)
  |
  v
Alembic migrations
```

## Requirements

- Python 3.12 or 3.13
- For local/test execution: SQLite (bundled with Python)
- For production deployment: PostgreSQL 17 and the optional `psycopg` dependency
- Docker is optional for deployment; the repository includes a Dockerfile and Compose definition.

## Clean installation

```bash
python3 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e '.[test]'
cp .env.example .env
```

Set a private API key in `.env` before exposing the API. Never commit `.env`.

Initialize the database:

```bash
AMIS_ENV=development AMIS_API_KEY='change-this-to-a-long-random-value' python -m alembic upgrade head
```

Run tests:

```bash
pytest
```

Start the API:

```bash
AMIS_ENV=development AMIS_API_KEY='change-this-to-a-long-random-value' python -m uvicorn amis.api:app --host 127.0.0.1 --port 8000
```

Health check:

```bash
curl http://127.0.0.1:8000/health
```

## API

### Create an opportunity

`POST /v1/opportunities`

Required headers: `X-AMIS-API-Key` and a unique `Idempotency-Key` (16–128 characters). Repeating a completed request with the same key returns the original opportunity instead of creating a duplicate.

The request requires probabilities that sum exactly to 1.0. The server calculates expected value and composite score; callers cannot supply those derived values.

### List opportunities

`GET /v1/opportunities?limit=50&offset=0`

### Get opportunity

`GET /v1/opportunities/{id}`

### Screen opportunity

`POST /v1/opportunities/{id}/decision`

The screening layer returns `CANDIDATE` only when the opportunity passes configured confidence, data-quality, score, and single-opportunity risk thresholds. Otherwise it returns `NO_ACTION` with explicit reasons.

## Security boundary

- Mutating/read API endpoints require an API key.
- API-key comparison uses constant-time comparison.
- Request payloads reject unknown fields and enforce numerical bounds.
- Secrets are environment variables, not source-controlled configuration.
- Rate limiting is process-local in Phase 1; a distributed limiter is required before horizontally scaled public deployment.
- There is no execution authority in this phase.

## Configuration

- `config/app.yaml` contains non-secret application/scoring defaults.
- `config/risk.yaml` contains risk thresholds.
- `.env` contains runtime secrets and environment-specific overrides.

## Limitations / explicit non-goals

- No market-data provider is connected yet.
- No live trading or transaction execution is implemented.
- No external due-diligence provider is connected.
- No distributed rate limiter is implemented.
- PostgreSQL production runtime was not executable in the supplied verification environment because Docker is unavailable and the PostgreSQL driver is not installed.
