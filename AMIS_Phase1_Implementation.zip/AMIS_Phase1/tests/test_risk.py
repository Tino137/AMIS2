from decimal import Decimal

import pytest

from amis.risk import evaluate_opportunity_risk, risk_at_invalidation


def test_risk_at_invalidation() -> None:
    assert risk_at_invalidation(Decimal("1000"), Decimal("0.02")) == Decimal("20")


def test_risk_rejects_invalid_loss_fraction() -> None:
    with pytest.raises(ValueError):
        risk_at_invalidation(Decimal("1000"), Decimal("1.1"))


def test_risk_governor_rejects_high_loss() -> None:
    decision = evaluate_opportunity_risk(
        capital_required=Decimal("1000"), failure_loss=Decimal("30"), confidence_score=Decimal("0.9"),
        data_quality_score=Decimal("0.95"), composite_score=Decimal("0.8"),
        max_single_risk_fraction=Decimal("0.02"), min_confidence_score=Decimal("0.7"),
        min_data_quality_score=Decimal("0.9"), min_opportunity_score=Decimal("0.6"),
    )
    assert decision.allowed is False
    assert any("risk fraction" in reason for reason in decision.reasons)


def test_risk_rejects_low_data_quality_and_confidence() -> None:
    decision = evaluate_opportunity_risk(
        capital_required=Decimal("1000"), failure_loss=Decimal("10"), confidence_score=Decimal("0.5"),
        data_quality_score=Decimal("0.5"), composite_score=Decimal("0.8"),
        max_single_risk_fraction=Decimal("0.02"), min_confidence_score=Decimal("0.7"),
        min_data_quality_score=Decimal("0.9"), min_opportunity_score=Decimal("0.6"),
    )
    assert decision.allowed is False
    assert len(decision.reasons) == 2
