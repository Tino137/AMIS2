from decimal import Decimal

from fastapi.testclient import TestClient

from amis.api import app


PAYLOAD = {
    "domain": "commercial",
    "title": "Verified supplier pricing discrepancy",
    "description": "A test opportunity with sufficient evidence and controlled downside.",
    "asset_or_counterparty": "Test Supplier",
    "capital_required": "1000",
    "potential_profit": "300",
    "probability_success": "0.8",
    "probability_failure": "0.2",
    "failure_loss": "10",
    "execution_cost": "5",
    "time_to_completion_hours": "24",
    "liquidity_score": "0.9",
    "evidence_score": "0.9",
    "risk_score": "0.1",
    "execution_complexity_score": "0.1",
    "confidence_score": "0.9",
    "data_quality_score": "0.95",
    "evidence": [{"source": "internal-test", "claim": "Test evidence", "reliability_score": "0.9"}],
}


def test_health() -> None:
    with TestClient(app) as client:
        response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok", "database": "ok"}


def test_authentication_is_required() -> None:
    with TestClient(app) as client:
        response = client.post("/v1/opportunities", json=PAYLOAD, headers={"Idempotency-Key": "idempotency-test-unauth"})
    assert response.status_code == 401


def test_create_get_list_and_decide() -> None:
    headers = {"X-AMIS-API-Key": "test-api-key-1234567890"}
    with TestClient(app) as client:
        created = client.post("/v1/opportunities", json=PAYLOAD, headers={**headers, "Idempotency-Key": "idempotency-test-0001"})
        assert created.status_code == 201
        body = created.json()
        assert Decimal(body["expected_value"]) == Decimal("233.00000000")
        assert body["status"] == "discovered"

        replay = client.post("/v1/opportunities", json=PAYLOAD, headers={**headers, "Idempotency-Key": "idempotency-test-0001"})
        assert replay.status_code == 200
        assert replay.json()["id"] == body["id"]

        opportunity_id = body["id"]
        fetched = client.get(f"/v1/opportunities/{opportunity_id}", headers=headers)
        assert fetched.status_code == 200
        assert fetched.json()["id"] == opportunity_id

        listed = client.get("/v1/opportunities", headers=headers)
        assert listed.status_code == 200
        assert any(item["id"] == opportunity_id for item in listed.json())

        decision = client.post(f"/v1/opportunities/{opportunity_id}/decision", headers=headers)
        assert decision.status_code == 200
        assert decision.json()["decision"] == "CANDIDATE"


def test_validation_rejects_probability_mismatch() -> None:
    headers = {"X-AMIS-API-Key": "test-api-key-1234567890"}
    bad = dict(PAYLOAD)
    bad["probability_failure"] = "0.3"
    with TestClient(app) as client:
        response = client.post("/v1/opportunities", json=bad, headers={**headers, "Idempotency-Key": "idempotency-test-bad"})
    assert response.status_code == 422


def test_missing_opportunity_returns_404() -> None:
    headers = {"X-AMIS-API-Key": "test-api-key-1234567890"}
    with TestClient(app) as client:
        response = client.get("/v1/opportunities/not-a-real-id", headers=headers)
    assert response.status_code == 404


def test_database_failure_returns_503(monkeypatch) -> None:
    from amis import api

    def broken_connect():
        raise RuntimeError("database unavailable")

    monkeypatch.setattr(api.engine, "connect", broken_connect)
    with TestClient(app) as client:
        response = client.get("/health")
    assert response.status_code == 503


def test_malformed_json_is_rejected() -> None:
    headers = {"X-AMIS-API-Key": "test-api-key-1234567890", "Idempotency-Key": "malformed-json-0001"}
    with TestClient(app) as client:
        response = client.post(
            "/v1/opportunities", content='{"domain":', headers={**headers, "Content-Type": "application/json"}
        )
    assert response.status_code == 422
