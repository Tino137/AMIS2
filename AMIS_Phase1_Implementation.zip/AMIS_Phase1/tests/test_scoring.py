from decimal import Decimal

import pytest

from amis.scoring import composite_score, expected_value


def test_expected_value_is_deterministic() -> None:
    value = expected_value(Decimal("0.7"), Decimal("100"), Decimal("0.3"), Decimal("40"), Decimal("5"))
    assert value == Decimal("53.00000000")


def test_composite_score_respects_risk_and_complexity() -> None:
    weights = {
        "economic_value": Decimal("0.20"), "probability": Decimal("0.20"),
        "evidence_quality": Decimal("0.15"), "liquidity": Decimal("0.10"),
        "time_efficiency": Decimal("0.10"), "capital_efficiency": Decimal("0.10"),
        "risk": Decimal("0.10"), "execution_complexity": Decimal("0.05"),
    }
    low_risk = composite_score(
        economic_value=Decimal("0.8"), probability=Decimal("0.8"), evidence_quality=Decimal("0.9"),
        liquidity=Decimal("0.9"), time_efficiency=Decimal("0.8"), capital_efficiency=Decimal("0.7"),
        risk=Decimal("0.1"), execution_complexity=Decimal("0.1"), weights=weights,
    )
    high_risk = composite_score(
        economic_value=Decimal("0.8"), probability=Decimal("0.8"), evidence_quality=Decimal("0.9"),
        liquidity=Decimal("0.9"), time_efficiency=Decimal("0.8"), capital_efficiency=Decimal("0.7"),
        risk=Decimal("0.9"), execution_complexity=Decimal("0.9"), weights=weights,
    )
    assert low_risk > high_risk


def test_probability_sum_must_equal_one() -> None:
    from amis.schemas import OpportunityCreate
    with pytest.raises(ValueError):
        OpportunityCreate(
            domain="commercial", title="Test opportunity", description="A sufficiently long description.",
            asset_or_counterparty="Counterparty", capital_required=10, potential_profit=20,
            probability_success=Decimal("0.6"), probability_failure=Decimal("0.3"), failure_loss=5,
            execution_cost=1, time_to_completion_hours=24, liquidity_score=.8, evidence_score=.8,
            risk_score=.2, execution_complexity_score=.2, confidence_score=.9, data_quality_score=.95,
        )
