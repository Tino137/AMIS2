import os

os.environ["AMIS_ENV"] = "test"
os.environ["AMIS_DATABASE_URL"] = "sqlite:///./test_amis.db"
os.environ["AMIS_API_KEY"] = "test-api-key-1234567890"
os.environ["AMIS_RATE_LIMIT_REQUESTS"] = "100"
os.environ["AMIS_RATE_LIMIT_WINDOW_SECONDS"] = "60"
