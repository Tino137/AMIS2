# AMIS Phase 1 Architecture

## Components

| Component | Responsibility |
|---|---|
| `settings.py` | Environment parsing and runtime validation |
| `db.py` | SQLAlchemy engine/session lifecycle |
| `models.py` | Persistent opportunity model |
| `schemas.py` | API input/output contracts and validation |
| `scoring.py` | Deterministic EV and composite scoring |
| `risk.py` | Central opportunity risk screening |
| `service.py` | Domain orchestration |
| `auth.py` | API-key authentication and local rate limiting |
| `api.py` | HTTP interface and lifecycle |
| Alembic | Versioned database migrations |

## Data flow

1. Client submits an opportunity candidate.
2. Pydantic validates type, bounds, required fields, and probability conservation.
3. Service calculates expected value.
4. Service calculates normalized time/capital efficiency and composite score.
5. The complete candidate is persisted transactionally.
6. Screening applies central risk/data-quality/confidence/score gates.
7. The decision endpoint returns an auditable decision and reasons.

## Security boundaries

The API is the trust boundary. Authentication occurs before opportunity operations. Validation occurs before persistence. Derived metrics are server-owned. No endpoint has execution authority.

## Persistence

SQLAlchemy supports SQLite for development/test and PostgreSQL for deployment. Alembic is the schema authority for production. Local non-production startup can create tables automatically for developer convenience.

## Failure behavior

Database failures cause request failure and rollback. Authentication failures return 401. Validation failures return 422. Missing resources return 404. Rate limits return 429. Health checks return 503 when the database is unavailable.
