# Configuration

## Environment variables

| Variable | Required | Purpose |
|---|---|---|
| `AMIS_ENV` | No | `development`, `test`, or `production` |
| `AMIS_DATABASE_URL` | No | SQLAlchemy URL; SQLite by default |
| `AMIS_API_KEY` | Yes for real use | API authentication secret |
| `AMIS_LOG_LEVEL` | No | Logging level |
| `AMIS_API_HOST` | No | Bind address |
| `AMIS_API_PORT` | No | Listen port |
| `AMIS_RATE_LIMIT_REQUESTS` | No | Requests per process/window |
| `AMIS_RATE_LIMIT_WINDOW_SECONDS` | No | Rate-limit window |

Production must not use the development API key.

## Risk thresholds

`config/risk.yaml` defines the screening thresholds. Changes should be version-controlled and reviewed because they alter capital/risk decisions.
