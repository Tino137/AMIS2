# Phase 1 File Manifest

| Path | Purpose |
|---|---|
| `pyproject.toml` | Package metadata and pinned runtime/test dependencies |
| `.env.example` | Non-secret runtime configuration template |
| `.gitignore` | Prevents secrets, caches, databases, and build artifacts from source control |
| `Dockerfile` | Container image definition |
| `docker-compose.yml` | Local PostgreSQL + API deployment topology |
| `alembic.ini` | Migration configuration |
| `config/app.yaml` | Application and scoring configuration |
| `config/risk.yaml` | Risk/screening thresholds |
| `src/amis/settings.py` | Runtime settings and YAML configuration loading |
| `src/amis/db.py` | SQLAlchemy engine/session management |
| `src/amis/models.py` | Persistent opportunity schema |
| `src/amis/schemas.py` | API validation and response models |
| `src/amis/scoring.py` | EV and composite-score calculations |
| `src/amis/risk.py` | Risk/screening decision logic |
| `src/amis/service.py` | Opportunity domain orchestration |
| `src/amis/auth.py` | API-key authentication and rate limiting |
| `src/amis/logging_config.py` | Application logging configuration |
| `src/amis/api.py` | FastAPI application and endpoints |
| `src/amis/main.py` | CLI/API process entry point |
| `migrations/env.py` | Alembic environment integration |
| `migrations/script.py.mako` | Alembic migration template |
| `migrations/versions/0001_initial.py` | Initial opportunity schema migration |
| `tests/conftest.py` | Isolated test environment variables |
| `tests/test_scoring.py` | Scoring unit tests |
| `tests/test_risk.py` | Risk unit tests |
| `tests/test_auth.py` | Rate limiter tests |
| `tests/test_api.py` | API/integration/security/failure tests |
| `tests/test_failure_modes.py` | Negative input tests |
| `tests/test_migrations.py` | Migration execution tests |
| `scripts/verify_local.sh` | Repeatable local verification command set |
| `README.md` | Project overview and installation |
| `docs/*.md` | Architecture, security, testing, deployment, troubleshooting, scope, failure analysis, traceability |
| `docs/openapi.json` | Generated API contract |
