# Phase 1 Scope Contract

## Included

- AMIS project runtime foundation.
- Opportunity domain model and API contract.
- Opportunity taxonomy enum.
- Expected-value calculation.
- Composite opportunity scoring.
- Central risk/screening gate.
- Configurable risk thresholds.
- Persistent opportunity storage.
- Versioned database migration.
- Authentication and process-local rate limiting.
- Automated unit/API/failure tests.
- Local installation and deployment documentation.

## Deferred to later phases

- Live market/on-chain/web ingestion.
- Provider adapters and source lineage pipeline.
- Data-quality engine beyond submitted candidate scores.
- Regime detection from live data.
- Strategy zoo execution.
- Portfolio construction and capital allocation.
- Broker/exchange execution.
- Monte Carlo/backtest engine.
- Learning/model lifecycle.
- Full audit/event ledger for external actions.

## Hard safety boundary

No production transaction or trade can be executed by Phase 1 because there is no execution adapter and the application configuration explicitly disallows execution.
