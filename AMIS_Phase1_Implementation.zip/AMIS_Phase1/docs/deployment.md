# Deployment

## Local / development

Use SQLite and run Alembic migrations before starting the API.

## Production

Use PostgreSQL and set `AMIS_DATABASE_URL` to a `postgresql+psycopg://...` URL. Install the optional PostgreSQL dependency with:

```bash
python -m pip install -e '.[postgres]'
```

Run migrations:

```bash
python -m alembic upgrade head
```

Start:

```bash
uvicorn amis.api:app --host 0.0.0.0 --port 8000
```

Use a secrets manager or orchestrator secret mechanism for `AMIS_API_KEY`; do not put production credentials in Compose files, images, or Git.

The included Dockerfile/Compose definition is a deployment template. Container execution was not verified in this environment because Docker is unavailable.
