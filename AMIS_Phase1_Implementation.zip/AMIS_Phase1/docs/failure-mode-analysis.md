# Phase 1 Failure-Mode Analysis

| Failure Mode | Cause | Probability | Impact | Detection | Mitigation | Recovery |
|---|---|---:|---:|---|---|---|
| Invalid request | Client sends malformed/out-of-range values | High | Medium | 422 validation | Pydantic bounds + strict model fields | Correct request |
| Authentication failure | Missing/incorrect API key | Medium | Medium | 401 | Constant-time API-key comparison | Supply valid credential |
| Database unavailable | DB process/network failure | Medium | High | Health check / exception | Transaction scope + health endpoint | Restore DB and retry |
| Duplicate request | Client retries same creation request | Medium | Medium | Phase 1 has no idempotency key | Keep creation non-executing; future phase adds idempotency | Reconcile records |
| Rate exhaustion | Client or attacker exceeds request limit | Medium | Medium | 429 | Per-process rate limiter | Wait/window reset or tune limit |
| Invalid probability model | Probabilities do not conserve to 1 | Medium | High | Schema validator | Exact probability-sum validation | Correct model input |
| Poor data quality | Candidate uses unreliable/stale evidence | Medium | High | Data-quality field + screening threshold | Minimum data-quality gate | Refresh/revalidate evidence |
| Excessive downside | Failure loss exceeds risk fraction | Medium | Critical | Risk governor | Hard rejection from candidate decision | Reduce downside or reject |
| Configuration drift | Runtime threshold differs from reviewed config | Low | High | Versioned config | Source-controlled YAML + deployment review | Restore reviewed configuration |
| Secret exposure | API key committed/logged | Low | High | Repository/security review | Environment secret + no secret logging | Rotate secret immediately |
