# Troubleshooting

## 401 invalid API key

Set `AMIS_API_KEY` to the same secret supplied in the `X-AMIS-API-Key` request header. Restart the process after changing environment variables.

## 503 health check

Verify `AMIS_DATABASE_URL`, database reachability, credentials, and migrations. For local development, SQLite requires no separate database server.

## Migration errors

Check the current revision:

```bash
python -m alembic current
```

Then inspect:

```bash
python -m alembic heads
```

Apply:

```bash
python -m alembic upgrade head
```

## 429 rate limit

Increase the configured rate only after confirming the client behavior. Phase 1 limiting is process-local and is not a substitute for a distributed gateway limiter.
