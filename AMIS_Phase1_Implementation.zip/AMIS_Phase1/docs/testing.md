# Testing

The Phase 1 suite contains:

- Unit tests for EV/scoring and risk calculations.
- Schema validation and negative-input tests.
- API authentication, validation, CRUD/read workflow, screening, 404, and health tests.
- Migration-head verification.

Run:

```bash
pytest -q
python -m compileall -q src tests
python -m pip check
```

The supplied environment did not contain Ruff or mypy and did not permit downloading them, so those two checks are explicitly environment-blocked rather than represented as passing results.
