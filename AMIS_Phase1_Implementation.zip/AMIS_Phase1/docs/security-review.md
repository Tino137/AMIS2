# Phase 1 Security Review

## Implemented controls

- API key required for all protected endpoints.
- Constant-time credential comparison via `hmac.compare_digest`.
- Unknown JSON fields rejected by Pydantic models.
- Numeric bounds enforced for probabilities, scores, capital, and time.
- Derived EV and composite score cannot be supplied by the client.
- SQLAlchemy parameterization is used instead of string-built SQL for application queries.
- Environment secrets are excluded from Git.
- Rate limiting is applied to protected endpoints.
- Idempotency keys prevent duplicate creation on client retries.
- No execution capability exists in Phase 1.

## Residual risks

- Shared API key is intentionally simple for Phase 1; production multi-user RBAC/OIDC is deferred.
- Rate limiting is process-local and must move to an edge/distributed control before horizontal scaling.
- Dependency vulnerability scanning could not be executed because `pip-audit` is unavailable and package installation is blocked.
- PostgreSQL/production container hardening could not be runtime-verified in this environment.
