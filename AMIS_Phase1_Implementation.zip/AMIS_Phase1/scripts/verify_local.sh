#!/usr/bin/env bash
set -euo pipefail

export AMIS_ENV="test"
export AMIS_DATABASE_URL="sqlite:///./amis_verify.db"
export AMIS_API_KEY="local-verification-key-1234567890"

rm -f amis_verify.db migration_test.db test_amis.db
python -m compileall -q src tests migrations
pytest -q
python -m alembic upgrade head
python -m alembic current
python -m alembic heads
rm -f amis_verify.db migration_test.db test_amis.db
