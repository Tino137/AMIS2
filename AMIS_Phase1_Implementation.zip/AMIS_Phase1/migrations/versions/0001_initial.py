"""create opportunities table

Revision ID: 0001_initial
Revises:
Create Date: 2026-10-07
"""
from alembic import op
import sqlalchemy as sa

revision = "0001_initial"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "opportunities",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column("idempotency_key", sa.String(length=128), nullable=False),
        sa.Column("domain", sa.Enum(
            "FINANCIAL_MARKET", "DIGITAL_ASSET", "PRIVATE_MARKET", "COMMERCIAL", "TECHNOLOGY", "INFORMATION",
            name="opportunitydomain"
        ), nullable=False),
        sa.Column("status", sa.Enum(
            "DISCOVERED", "VERIFIED", "REJECTED", "APPROVED", "EXECUTABLE", name="opportunitystatus"
        ), nullable=False),
        sa.Column("title", sa.String(length=200), nullable=False),
        sa.Column("description", sa.Text(), nullable=False),
        sa.Column("asset_or_counterparty", sa.String(length=200), nullable=False),
        sa.Column("capital_required", sa.Numeric(20, 8), nullable=False),
        sa.Column("potential_profit", sa.Numeric(20, 8), nullable=False),
        sa.Column("probability_success", sa.Numeric(8, 6), nullable=False),
        sa.Column("probability_failure", sa.Numeric(8, 6), nullable=False),
        sa.Column("failure_loss", sa.Numeric(20, 8), nullable=False),
        sa.Column("execution_cost", sa.Numeric(20, 8), nullable=False),
        sa.Column("time_to_completion_hours", sa.Numeric(14, 4), nullable=False),
        sa.Column("liquidity_score", sa.Numeric(8, 6), nullable=False),
        sa.Column("evidence_score", sa.Numeric(8, 6), nullable=False),
        sa.Column("risk_score", sa.Numeric(8, 6), nullable=False),
        sa.Column("execution_complexity_score", sa.Numeric(8, 6), nullable=False),
        sa.Column("confidence_score", sa.Numeric(8, 6), nullable=False),
        sa.Column("data_quality_score", sa.Numeric(8, 6), nullable=False),
        sa.Column("expected_value", sa.Numeric(20, 8), nullable=False),
        sa.Column("composite_score", sa.Numeric(8, 6), nullable=False),
        sa.Column("evidence", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("idempotency_key"),
    )
    op.create_index("ix_opportunities_idempotency_key", "opportunities", ["idempotency_key"], unique=True)
    op.create_index("ix_opportunities_domain", "opportunities", ["domain"])
    op.create_index("ix_opportunities_status", "opportunities", ["status"])


def downgrade() -> None:
    op.drop_index("ix_opportunities_status", table_name="opportunities")
    op.drop_index("ix_opportunities_idempotency_key", table_name="opportunities")
    op.drop_index("ix_opportunities_domain", table_name="opportunities")
    op.drop_table("opportunities")
