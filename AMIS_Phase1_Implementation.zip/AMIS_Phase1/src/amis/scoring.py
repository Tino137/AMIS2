from __future__ import annotations

from decimal import Decimal, ROUND_HALF_UP


ZERO = Decimal("0")
ONE = Decimal("1")
HUNDRED = Decimal("100")


def money(value: Decimal) -> Decimal:
    return value.quantize(Decimal("0.00000001"), rounding=ROUND_HALF_UP)


def score(value: Decimal) -> Decimal:
    return value.quantize(Decimal("0.000001"), rounding=ROUND_HALF_UP)


def expected_value(
    probability_success: Decimal,
    potential_profit: Decimal,
    probability_failure: Decimal,
    failure_loss: Decimal,
    execution_cost: Decimal,
) -> Decimal:
    return money(
        probability_success * potential_profit
        - probability_failure * failure_loss
        - execution_cost
    )


def composite_score(
    *,
    economic_value: Decimal,
    probability: Decimal,
    evidence_quality: Decimal,
    liquidity: Decimal,
    time_efficiency: Decimal,
    capital_efficiency: Decimal,
    risk: Decimal,
    execution_complexity: Decimal,
    weights: dict[str, Decimal],
) -> Decimal:
    for name, value in {
        "economic_value": economic_value,
        "probability": probability,
        "evidence_quality": evidence_quality,
        "liquidity": liquidity,
        "time_efficiency": time_efficiency,
        "capital_efficiency": capital_efficiency,
        "risk": risk,
        "execution_complexity": execution_complexity,
    }.items():
        if not ZERO <= value <= ONE:
            raise ValueError(f"{name} must be between 0 and 1")
    if set(weights) != {
        "economic_value", "probability", "evidence_quality", "liquidity",
        "time_efficiency", "capital_efficiency", "risk", "execution_complexity",
    }:
        raise ValueError("scoring weights are incomplete or contain unknown keys")
    if sum(weights.values(), ZERO) != ONE:
        raise ValueError("scoring weights must sum exactly to 1")

    # Higher risk and higher execution complexity reduce the score.
    raw = (
        economic_value * weights["economic_value"]
        + probability * weights["probability"]
        + evidence_quality * weights["evidence_quality"]
        + liquidity * weights["liquidity"]
        + time_efficiency * weights["time_efficiency"]
        + capital_efficiency * weights["capital_efficiency"]
        + (ONE - risk) * weights["risk"]
        + (ONE - execution_complexity) * weights["execution_complexity"]
    )
    return score(max(ZERO, min(ONE, raw)))
