from __future__ import annotations

from decimal import Decimal


class RiskDecision:
    def __init__(self, allowed: bool, reasons: list[str]) -> None:
        self.allowed = allowed
        self.reasons = reasons


def risk_at_invalidation(position_size: Decimal, loss_fraction: Decimal) -> Decimal:
    if position_size < 0 or not Decimal("0") <= loss_fraction <= Decimal("1"):
        raise ValueError("position_size must be non-negative and loss_fraction must be in [0, 1]")
    return position_size * loss_fraction


def evaluate_opportunity_risk(
    *,
    capital_required: Decimal,
    failure_loss: Decimal,
    confidence_score: Decimal,
    data_quality_score: Decimal,
    composite_score: Decimal,
    max_single_risk_fraction: Decimal,
    min_confidence_score: Decimal,
    min_data_quality_score: Decimal,
    min_opportunity_score: Decimal,
) -> RiskDecision:
    reasons: list[str] = []
    if capital_required <= 0:
        reasons.append("capital_required must be positive")
    if capital_required > 0 and failure_loss / capital_required > max_single_risk_fraction:
        reasons.append("failure loss exceeds maximum single-opportunity risk fraction")
    if confidence_score < min_confidence_score:
        reasons.append("confidence score is below risk threshold")
    if data_quality_score < min_data_quality_score:
        reasons.append("data quality score is below risk threshold")
    if composite_score < min_opportunity_score:
        reasons.append("composite opportunity score is below threshold")
    return RiskDecision(allowed=not reasons, reasons=reasons)
