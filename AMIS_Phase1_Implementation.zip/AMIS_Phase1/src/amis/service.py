from __future__ import annotations

from decimal import Decimal

from sqlalchemy import select
from sqlalchemy.orm import Session

from .models import Opportunity, OpportunityStatus
from .risk import evaluate_opportunity_risk
from .schemas import OpportunityCreate
from .scoring import composite_score, expected_value, score
from .settings import RiskConfig, load_scoring_weights


class OpportunityService:
    def __init__(self, risk_config: RiskConfig) -> None:
        self.risk_config = risk_config
        self.weights = load_scoring_weights()

    def create(self, session: Session, payload: OpportunityCreate, idempotency_key: str) -> tuple[Opportunity, bool]:
        existing = session.scalar(select(Opportunity).where(Opportunity.idempotency_key == idempotency_key))
        if existing is not None:
            return existing, True
        ev = expected_value(
            payload.probability_success,
            payload.potential_profit,
            payload.probability_failure,
            payload.failure_loss,
            payload.execution_cost,
        )
        economic_value = score(
            ev / payload.capital_required if payload.capital_required else Decimal("0")
        )
        time_efficiency = score(Decimal("1") / (Decimal("1") + payload.time_to_completion_hours / Decimal("24")))
        capital_efficiency = score(
            payload.potential_profit / payload.capital_required
            if payload.capital_required else Decimal("0")
        )
        comp = composite_score(
            economic_value=economic_value,
            probability=payload.probability_success,
            evidence_quality=payload.evidence_score,
            liquidity=payload.liquidity_score,
            time_efficiency=time_efficiency,
            capital_efficiency=capital_efficiency,
            risk=payload.risk_score,
            execution_complexity=payload.execution_complexity_score,
            weights=self.weights,
        )
        opportunity = Opportunity(
            **payload.model_dump(exclude={"evidence"}),
            idempotency_key=idempotency_key,
            evidence=[item.model_dump(mode="json") for item in payload.evidence],
            expected_value=ev,
            composite_score=comp,
            status=OpportunityStatus.DISCOVERED,
        )
        session.add(opportunity)
        session.commit()
        session.refresh(opportunity)
        return opportunity, False

    def get(self, session: Session, opportunity_id: str) -> Opportunity | None:
        return session.get(Opportunity, opportunity_id)

    def list(self, session: Session, limit: int, offset: int) -> list[Opportunity]:
        statement = (
            select(Opportunity)
            .order_by(Opportunity.composite_score.desc(), Opportunity.created_at.desc())
            .limit(limit)
            .offset(offset)
        )
        return list(session.scalars(statement))

    def decision(self, opportunity: Opportunity) -> tuple[str, list[str]]:
        risk = evaluate_opportunity_risk(
            capital_required=opportunity.capital_required,
            failure_loss=opportunity.failure_loss,
            confidence_score=opportunity.confidence_score,
            data_quality_score=opportunity.data_quality_score,
            composite_score=opportunity.composite_score,
            max_single_risk_fraction=self.risk_config.max_single_opportunity_risk_fraction,
            min_confidence_score=self.risk_config.min_confidence_score,
            min_data_quality_score=self.risk_config.min_data_quality_score,
            min_opportunity_score=self.risk_config.min_opportunity_score,
        )
        if not risk.allowed:
            return "NO_ACTION", risk.reasons
        return "CANDIDATE", ["opportunity passed Phase 1 screening gates"]
