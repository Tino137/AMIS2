from __future__ import annotations

import uvicorn

from .settings import get_settings


def cli() -> None:
    settings = get_settings()
    uvicorn.run("amis.api:app", host=settings.api_host, port=settings.api_port, reload=False)


if __name__ == "__main__":
    cli()
