"""Shared SQLAlchemy metadata without creating a database engine."""

from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    """Base class shared by all ORM models and Alembic migrations."""
