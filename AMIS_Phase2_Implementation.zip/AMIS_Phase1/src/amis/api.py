from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI, Header, HTTPException, Query, Request, Response, status
from sqlalchemy import select, text

from .auth import RateLimiter, rate_limit, require_api_key
from .db import Base, engine, session_scope
from .logging_config import configure_logging
from .schemas import DecisionResponse, OpportunityCreate, OpportunityResponse
from .service import OpportunityService
from .market_models import DiscoveryCandidate, MarketObservation
from .market_schemas import DiscoveryResponse, FeatureResponse, ObservationBatch, ObservationIngestResponse
from .market_service import ingest_observations
from .features import calculate_features
from .discovery import discover_candidates
from .settings import get_settings, load_risk_config

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(application: FastAPI):
    settings = get_settings()
    configure_logging(settings.log_level)
    if settings.environment != "production":
        try:
            Base.metadata.create_all(bind=engine)
        except Exception:
            logger.exception("database initialization failed; service will remain unhealthy")
    application.state.rate_limiter = RateLimiter(
        settings.rate_limit_requests, settings.rate_limit_window_seconds
    )
    application.state.opportunity_service = OpportunityService(load_risk_config())
    yield


app = FastAPI(title="AMIS Market & Intelligence API", version="0.2.0", lifespan=lifespan)


@app.get("/health", tags=["system"])
def health() -> dict[str, str]:
    try:
        with engine.connect() as connection:
            connection.execute(text("SELECT 1"))
        return {"status": "ok", "database": "ok"}
    except Exception:
        logger.exception("health check failed")
        raise HTTPException(status_code=503, detail="service unavailable") from None


@app.post(
    "/v1/opportunities",
    response_model=OpportunityResponse,
    status_code=status.HTTP_201_CREATED,
    dependencies=[Depends(require_api_key), Depends(rate_limit)],
    tags=["opportunities"],
)
def create_opportunity(
    payload: OpportunityCreate,
    request: Request,
    response: Response,
    idempotency_key: str = Header(min_length=16, max_length=128),
) -> OpportunityResponse:
    service: OpportunityService = request.app.state.opportunity_service
    with session_scope() as session:
        opportunity, replayed = service.create(session, payload, idempotency_key)
        if replayed:
            response.status_code = status.HTTP_200_OK
        return opportunity


@app.get(
    "/v1/opportunities",
    response_model=list[OpportunityResponse],
    dependencies=[Depends(require_api_key), Depends(rate_limit)],
    tags=["opportunities"],
)
def list_opportunities(
    request: Request,
    limit: int = Query(default=50, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
) -> list[OpportunityResponse]:
    service: OpportunityService = request.app.state.opportunity_service
    with session_scope() as session:
        return service.list(session, limit, offset)


@app.get(
    "/v1/opportunities/{opportunity_id}",
    response_model=OpportunityResponse,
    dependencies=[Depends(require_api_key), Depends(rate_limit)],
    tags=["opportunities"],
)
def get_opportunity(opportunity_id: str, request: Request) -> OpportunityResponse:
    service: OpportunityService = request.app.state.opportunity_service
    with session_scope() as session:
        opportunity = service.get(session, opportunity_id)
        if opportunity is None:
            raise HTTPException(status_code=404, detail="opportunity not found")
        return opportunity


@app.post(
    "/v1/opportunities/{opportunity_id}/decision",
    response_model=DecisionResponse,
    dependencies=[Depends(require_api_key), Depends(rate_limit)],
    tags=["opportunities"],
)
def screen_opportunity(opportunity_id: str, request: Request) -> DecisionResponse:
    service: OpportunityService = request.app.state.opportunity_service
    with session_scope() as session:
        opportunity = service.get(session, opportunity_id)
        if opportunity is None:
            raise HTTPException(status_code=404, detail="opportunity not found")
        decision, reasons = service.decision(opportunity)
        return DecisionResponse(
            opportunity_id=opportunity.id,
            decision=decision,
            expected_value=opportunity.expected_value,
            composite_score=opportunity.composite_score,
            reasons=reasons,
        )


@app.post("/v1/market/observations", response_model=ObservationIngestResponse, dependencies=[Depends(require_api_key), Depends(rate_limit)], tags=["market-data"])
def ingest_market_observations(payload: ObservationBatch) -> ObservationIngestResponse:
    with session_scope() as session:
        return ingest_observations(session, payload)


@app.get("/v1/market/{symbol}/features", response_model=FeatureResponse, dependencies=[Depends(require_api_key), Depends(rate_limit)], tags=["market-data"])
def market_features(symbol: str) -> FeatureResponse:
    with session_scope() as session:
        rows = list(session.scalars(select(MarketObservation).where(MarketObservation.symbol == symbol).order_by(MarketObservation.observed_at.desc()).limit(5000)))
        if not rows:
            raise HTTPException(status_code=404, detail="market observations not found")
        rows.reverse()
        return FeatureResponse.model_validate(calculate_features(rows))


@app.post("/v1/discovery/{symbol}", response_model=list[DiscoveryResponse], dependencies=[Depends(require_api_key), Depends(rate_limit)], tags=["discovery"])
def run_discovery(symbol: str) -> list[DiscoveryResponse]:
    with session_scope() as session:
        candidates = discover_candidates(session, symbol)
        return [DiscoveryResponse.model_validate(item) for item in candidates]


@app.get("/v1/discovery", response_model=list[DiscoveryResponse], dependencies=[Depends(require_api_key), Depends(rate_limit)], tags=["discovery"])
def list_discovery(limit: int = Query(default=50, ge=1, le=100), offset: int = Query(default=0, ge=0)) -> list[DiscoveryResponse]:
    with session_scope() as session:
        statement = select(DiscoveryCandidate).order_by(DiscoveryCandidate.created_at.desc()).limit(limit).offset(offset)
        return [DiscoveryResponse.model_validate(item) for item in session.scalars(statement)]
