from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, model_validator

from .models import OpportunityDomain, OpportunityStatus


class EvidenceItem(BaseModel):
    source: str = Field(min_length=1, max_length=300)
    claim: str = Field(min_length=1, max_length=1000)
    reliability_score: Decimal = Field(ge=Decimal("0"), le=Decimal("1"))


class OpportunityCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    domain: OpportunityDomain
    title: str = Field(min_length=3, max_length=200)
    description: str = Field(min_length=10, max_length=5000)
    asset_or_counterparty: str = Field(min_length=1, max_length=200)
    capital_required: Decimal = Field(gt=Decimal("0"))
    potential_profit: Decimal = Field(ge=Decimal("0"))
    probability_success: Decimal = Field(ge=Decimal("0"), le=Decimal("1"))
    probability_failure: Decimal = Field(ge=Decimal("0"), le=Decimal("1"))
    failure_loss: Decimal = Field(ge=Decimal("0"))
    execution_cost: Decimal = Field(ge=Decimal("0"))
    time_to_completion_hours: Decimal = Field(gt=Decimal("0"))
    liquidity_score: Decimal = Field(ge=Decimal("0"), le=Decimal("1"))
    evidence_score: Decimal = Field(ge=Decimal("0"), le=Decimal("1"))
    risk_score: Decimal = Field(ge=Decimal("0"), le=Decimal("1"))
    execution_complexity_score: Decimal = Field(ge=Decimal("0"), le=Decimal("1"))
    confidence_score: Decimal = Field(ge=Decimal("0"), le=Decimal("1"))
    data_quality_score: Decimal = Field(ge=Decimal("0"), le=Decimal("1"))
    evidence: list[EvidenceItem] = Field(default_factory=list, max_length=100)

    @model_validator(mode="after")
    def validate_probabilities(self) -> "OpportunityCreate":
        total = self.probability_success + self.probability_failure
        if total != Decimal("1"):
            raise ValueError("probability_success + probability_failure must equal exactly 1")
        return self


class OpportunityResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    domain: OpportunityDomain
    status: OpportunityStatus
    title: str
    description: str
    asset_or_counterparty: str
    capital_required: Decimal
    potential_profit: Decimal
    probability_success: Decimal
    probability_failure: Decimal
    failure_loss: Decimal
    execution_cost: Decimal
    time_to_completion_hours: Decimal
    liquidity_score: Decimal
    evidence_score: Decimal
    risk_score: Decimal
    execution_complexity_score: Decimal
    confidence_score: Decimal
    data_quality_score: Decimal
    expected_value: Decimal
    composite_score: Decimal
    evidence: list[dict[str, Any]]
    created_at: datetime
    updated_at: datetime


class DecisionResponse(BaseModel):
    opportunity_id: str
    decision: str
    expected_value: Decimal
    composite_score: Decimal
    reasons: list[str]
