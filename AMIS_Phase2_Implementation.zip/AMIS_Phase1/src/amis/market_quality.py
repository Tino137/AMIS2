from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from datetime import datetime, timezone

from .market_schemas import ObservationInput


@dataclass(frozen=True)
class QualityResult:
    score: Decimal
    flags: list[str]


def assess_observation(item: ObservationInput, now: datetime | None = None, stale_after_seconds: int = 86400) -> QualityResult:
    now = now or datetime.now(timezone.utc)
    flags: list[str] = []
    if item.volume == 0:
        flags.append("zero_volume")
    if item.observed_at > now:
        flags.append("future_timestamp")
    age = (now - item.observed_at).total_seconds()
    if age > stale_after_seconds:
        flags.append("stale_observation")
    if item.high / item.low > Decimal("100"):
        flags.append("extreme_intrabar_range")
    score = max(Decimal("0"), Decimal("1") - Decimal("0.25") * len(flags))
    return QualityResult(score=score.quantize(Decimal("0.000001")), flags=flags)
