from __future__ import annotations

from decimal import Decimal
from functools import lru_cache
from pathlib import Path

import yaml
from pydantic import Field, SecretStr, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="AMIS_",
        env_file=".env",
        extra="ignore",
    )

    environment: str = Field(default="development", validation_alias="AMIS_ENV")
    database_url: str = "sqlite:///./amis.db"
    api_key: SecretStr = Field(default=SecretStr("development-only-change-me"), min_length=16)
    log_level: str = "INFO"
    api_host: str = "127.0.0.1"
    api_port: int = Field(default=8000, ge=1, le=65535)
    rate_limit_requests: int = Field(default=60, ge=1)
    rate_limit_window_seconds: int = Field(default=60, ge=1)

    @field_validator("environment")
    @classmethod
    def validate_environment(cls, value: str) -> str:
        allowed = {"development", "test", "production"}
        if value not in allowed:
            raise ValueError(f"environment must be one of {sorted(allowed)}")
        return value

    @field_validator("log_level")
    @classmethod
    def validate_log_level(cls, value: str) -> str:
        value = value.upper()
        if value not in {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}:
            raise ValueError("unsupported log level")
        return value


class RiskConfig:
    def __init__(self, values: dict[str, object]) -> None:
        risk = values.get("risk", {})
        if not isinstance(risk, dict):
            raise ValueError("config/risk.yaml: risk must be a mapping")
        self.max_single_opportunity_risk_fraction = Decimal(str(risk["max_single_opportunity_risk_fraction"]))
        self.max_portfolio_risk_fraction = Decimal(str(risk["max_portfolio_risk_fraction"]))
        self.max_drawdown_fraction = Decimal(str(risk["max_drawdown_fraction"]))
        self.min_data_quality_score = Decimal(str(risk["min_data_quality_score"]))
        self.min_opportunity_score = Decimal(str(risk["min_opportunity_score"]))
        self.min_confidence_score = Decimal(str(risk["min_confidence_score"]))
        self.unknown_regime_blocks_execution = bool(risk["unknown_regime_blocks_execution"])
        self.stale_data_seconds = int(risk["stale_data_seconds"])
        for name in (
            "max_single_opportunity_risk_fraction",
            "max_portfolio_risk_fraction",
            "max_drawdown_fraction",
            "min_data_quality_score",
            "min_opportunity_score",
            "min_confidence_score",
        ):
            value = getattr(self, name)
            if not Decimal("0") <= value <= Decimal("1"):
                raise ValueError(f"{name} must be between 0 and 1")


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    settings = Settings()
    api_key = settings.api_key.get_secret_value()
    placeholder_markers = ("replace-with", "change-this", "development-only", "your-api-key")
    if settings.environment == "production" and (
        api_key in {"development-only-change-me", "replace-with-a-long-random-secret"}
        or any(marker in api_key.lower() for marker in placeholder_markers)
    ):
        raise ValueError("AMIS_API_KEY must be replaced with a unique secret in production")
    return settings



def load_scoring_weights(path: str | Path = "config/app.yaml") -> dict[str, Decimal]:
    with Path(path).open("r", encoding="utf-8") as handle:
        values = yaml.safe_load(handle) or {}
    scoring = values.get("scoring", {})
    if not isinstance(scoring, dict) or not isinstance(scoring.get("weights"), dict):
        raise ValueError("config/app.yaml: scoring.weights must be a mapping")
    weights = {str(key): Decimal(str(value)) for key, value in scoring["weights"].items()}
    if sum(weights.values(), Decimal("0")) != Decimal("1"):
        raise ValueError("config/app.yaml: scoring weights must sum exactly to 1")
    return weights


def load_risk_config(path: str | Path = "config/risk.yaml") -> RiskConfig:
    with Path(path).open("r", encoding="utf-8") as handle:
        values = yaml.safe_load(handle) or {}
    return RiskConfig(values)
