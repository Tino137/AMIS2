from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


class ObservationInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    source: str = Field(min_length=1, max_length=120, pattern=r"^[A-Za-z0-9_.:-]+$")
    symbol: str = Field(min_length=1, max_length=80, pattern=r"^[A-Za-z0-9._:/-]+$")
    observed_at: datetime
    open: Decimal = Field(gt=0, max_digits=24, decimal_places=10)
    high: Decimal = Field(gt=0, max_digits=24, decimal_places=10)
    low: Decimal = Field(gt=0, max_digits=24, decimal_places=10)
    close: Decimal = Field(gt=0, max_digits=24, decimal_places=10)
    volume: Decimal = Field(ge=0, max_digits=28, decimal_places=10)

    @field_validator("observed_at")
    @classmethod
    def timezone_required(cls, value: datetime) -> datetime:
        if value.tzinfo is None or value.utcoffset() is None:
            raise ValueError("observed_at must include a timezone")
        return value.astimezone(timezone.utc)

    @model_validator(mode="after")
    def validate_ohlc(self) -> "ObservationInput":
        if self.high < max(self.open, self.close, self.low):
            raise ValueError("high must be >= open, close, and low")
        if self.low > min(self.open, self.close, self.high):
            raise ValueError("low must be <= open, close, and high")
        return self


class ObservationBatch(BaseModel):
    model_config = ConfigDict(extra="forbid")
    observations: list[ObservationInput] = Field(min_length=1, max_length=5000)


class ObservationIngestResponse(BaseModel):
    accepted: int
    duplicates: int
    rejected_quality: int
    observation_ids: list[str]


class FeatureResponse(BaseModel):
    symbol: str
    count: int
    last_observed_at: datetime
    last_close: Decimal
    return_1: Decimal | None
    return_5: Decimal | None
    volatility: Decimal | None
    average_volume: Decimal
    volume_change: Decimal | None
    trend: str
    regime: str
    data_quality_score: Decimal
    quality_flags: list[str]


class DiscoveryResponse(BaseModel):
    id: str
    symbol: str
    strategy_id: str
    direction: str
    regime: str
    score: Decimal
    evidence: dict[str, object]
    decision: str
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)
