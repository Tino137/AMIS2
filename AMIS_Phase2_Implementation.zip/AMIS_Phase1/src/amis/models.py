from __future__ import annotations

import enum
import uuid
from datetime import datetime, timezone
from decimal import Decimal

from sqlalchemy import JSON, DateTime, Enum, Numeric, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from .db_base import Base


class OpportunityDomain(str, enum.Enum):
    FINANCIAL_MARKET = "financial_market"
    DIGITAL_ASSET = "digital_asset"
    PRIVATE_MARKET = "private_market"
    COMMERCIAL = "commercial"
    TECHNOLOGY = "technology"
    INFORMATION = "information"


class OpportunityStatus(str, enum.Enum):
    DISCOVERED = "discovered"
    VERIFIED = "verified"
    REJECTED = "rejected"
    APPROVED = "approved"
    EXECUTABLE = "executable"


class Opportunity(Base):
    __tablename__ = "opportunities"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    idempotency_key: Mapped[str] = mapped_column(String(128), nullable=False, unique=True, index=True)
    domain: Mapped[OpportunityDomain] = mapped_column(Enum(OpportunityDomain), nullable=False, index=True)
    status: Mapped[OpportunityStatus] = mapped_column(
        Enum(OpportunityStatus), nullable=False, default=OpportunityStatus.DISCOVERED, index=True
    )
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    asset_or_counterparty: Mapped[str] = mapped_column(String(200), nullable=False)
    capital_required: Mapped[Decimal] = mapped_column(Numeric(20, 8), nullable=False)
    potential_profit: Mapped[Decimal] = mapped_column(Numeric(20, 8), nullable=False)
    probability_success: Mapped[Decimal] = mapped_column(Numeric(8, 6), nullable=False)
    probability_failure: Mapped[Decimal] = mapped_column(Numeric(8, 6), nullable=False)
    failure_loss: Mapped[Decimal] = mapped_column(Numeric(20, 8), nullable=False)
    execution_cost: Mapped[Decimal] = mapped_column(Numeric(20, 8), nullable=False)
    time_to_completion_hours: Mapped[Decimal] = mapped_column(Numeric(14, 4), nullable=False)
    liquidity_score: Mapped[Decimal] = mapped_column(Numeric(8, 6), nullable=False)
    evidence_score: Mapped[Decimal] = mapped_column(Numeric(8, 6), nullable=False)
    risk_score: Mapped[Decimal] = mapped_column(Numeric(8, 6), nullable=False)
    execution_complexity_score: Mapped[Decimal] = mapped_column(Numeric(8, 6), nullable=False)
    confidence_score: Mapped[Decimal] = mapped_column(Numeric(8, 6), nullable=False)
    data_quality_score: Mapped[Decimal] = mapped_column(Numeric(8, 6), nullable=False)
    expected_value: Mapped[Decimal] = mapped_column(Numeric(20, 8), nullable=False)
    composite_score: Mapped[Decimal] = mapped_column(Numeric(8, 6), nullable=False)
    evidence: Mapped[list[dict[str, object]]] = mapped_column(JSON, nullable=False, default=list)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc), server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc)
    )
