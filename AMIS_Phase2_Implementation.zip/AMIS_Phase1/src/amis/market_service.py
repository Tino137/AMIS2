from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from .market_models import MarketObservation
from .market_quality import assess_observation
from .market_schemas import ObservationBatch, ObservationIngestResponse


def ingest_observations(session: Session, batch: ObservationBatch) -> ObservationIngestResponse:
    accepted = duplicates = rejected = 0
    ids: list[str] = []
    now = datetime.now(timezone.utc)
    for item in batch.observations:
        existing = session.scalar(select(MarketObservation.id).where(
            MarketObservation.source == item.source,
            MarketObservation.symbol == item.symbol,
            MarketObservation.observed_at == item.observed_at,
        ))
        if existing:
            duplicates += 1
            ids.append(existing)
            continue
        quality = assess_observation(item, now=now)
        if "future_timestamp" in quality.flags:
            rejected += 1
            continue
        record = MarketObservation(source=item.source, symbol=item.symbol, observed_at=item.observed_at,
            open=item.open, high=item.high, low=item.low, close=item.close, volume=item.volume,
            quality_score=quality.score, quality_flags=quality.flags)
        try:
            with session.begin_nested():
                session.add(record)
                session.flush()
        except IntegrityError:
            raced_id = session.scalar(select(MarketObservation.id).where(
                MarketObservation.source == item.source,
                MarketObservation.symbol == item.symbol,
                MarketObservation.observed_at == item.observed_at,
            ))
            if raced_id:
                duplicates += 1
                ids.append(raced_id)
                continue
            raise
        accepted += 1
        ids.append(record.id)
    session.commit()
    return ObservationIngestResponse(accepted=accepted, duplicates=duplicates, rejected_quality=rejected, observation_ids=ids)
