from __future__ import annotations

import csv
import json
import logging
import urllib.error
import urllib.request
from datetime import datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any, Protocol

from .market_schemas import ObservationInput

logger = logging.getLogger(__name__)


class MarketDataProvider(Protocol):
    """Provider-neutral market data source contract."""
    name: str
    def fetch(self, symbol: str) -> list[ObservationInput]: ...


class CsvMarketDataProvider:
    """Reads real OHLCV records from a local CSV with the documented column names."""
    def __init__(self, path: str | Path, name: str = "csv") -> None:
        self.path = Path(path)
        self.name = name

    def fetch(self, symbol: str) -> list[ObservationInput]:
        if not self.path.is_file():
            raise FileNotFoundError("market data CSV not found")
        records: list[ObservationInput] = []
        with self.path.open("r", newline="", encoding="utf-8-sig") as handle:
            reader = csv.DictReader(handle)
            required = {"timestamp", "symbol", "open", "high", "low", "close", "volume"}
            if not reader.fieldnames or not required.issubset(reader.fieldnames):
                raise ValueError("CSV must contain timestamp,symbol,open,high,low,close,volume")
            for line_number, row in enumerate(reader, start=2):
                if row["symbol"].strip() != symbol:
                    continue
                try:
                    records.append(ObservationInput(
                        source=self.name, symbol=symbol,
                        observed_at=datetime.fromisoformat(row["timestamp"].replace("Z", "+00:00")),
                        open=Decimal(row["open"]), high=Decimal(row["high"]), low=Decimal(row["low"]),
                        close=Decimal(row["close"]), volume=Decimal(row["volume"]),
                    ))
                except (ValueError, InvalidOperation, KeyError) as exc:
                    raise ValueError(f"invalid CSV record at line {line_number}") from exc
        return records


class JsonRestMarketDataProvider:
    """Fetches JSON from an explicitly configured HTTPS endpoint; never logs credentials."""
    def __init__(self, endpoint: str, token: str | None = None, name: str = "rest", timeout_seconds: float = 5.0) -> None:
        if not endpoint.lower().startswith("https://"):
            raise ValueError("market data endpoint must use HTTPS")
        if not 0 < timeout_seconds <= 30:
            raise ValueError("timeout_seconds must be in (0, 30]")
        self.endpoint, self.token, self.name, self.timeout_seconds = endpoint, token, name, timeout_seconds

    def fetch(self, symbol: str) -> list[ObservationInput]:
        from urllib.parse import urlencode
        url = f"{self.endpoint}{'&' if '?' in self.endpoint else '?'}{urlencode({'symbol': symbol})}"
        headers = {"Accept": "application/json", "User-Agent": "AMIS/0.2"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        request = urllib.request.Request(url, headers=headers, method="GET")
        try:
            with urllib.request.urlopen(request, timeout=self.timeout_seconds) as response:
                if response.status != 200:
                    raise RuntimeError(f"market data provider returned HTTP {response.status}")
                payload: Any = json.loads(response.read(5_000_001))
        except urllib.error.HTTPError as exc:
            if exc.code == 429:
                raise RuntimeError("market data provider rate limit reached") from exc
            raise RuntimeError(f"market data provider returned HTTP {exc.code}") from exc
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
            logger.warning("market data provider request failed", extra={"provider": self.name})
            raise RuntimeError("market data provider unavailable or returned invalid JSON") from exc
        if not isinstance(payload, list) or len(payload) > 5000:
            raise ValueError("provider response must be a JSON array of at most 5000 records")
        results = []
        for index, item in enumerate(payload):
            if not isinstance(item, dict):
                raise ValueError(f"provider returned a non-object record at index {index}")
            try:
                results.append(ObservationInput(source=self.name, symbol=symbol, observed_at=item["timestamp"],
                    open=item["open"], high=item["high"], low=item["low"], close=item["close"], volume=item["volume"]))
            except (KeyError, ValueError, TypeError) as exc:
                raise ValueError(f"provider returned an invalid OHLCV record at index {index}") from exc
        return results
