from __future__ import annotations

import hashlib
import json
from decimal import Decimal
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from .features import calculate_features
from .market_models import DiscoveryCandidate, MarketObservation


def discover_candidates(session: Session, symbol: str, min_quality: Decimal = Decimal("0.90")) -> list[DiscoveryCandidate]:
    rows = list(session.scalars(select(MarketObservation).where(MarketObservation.symbol == symbol).order_by(MarketObservation.observed_at.desc()).limit(5000)))
    if not rows:
        return []
    rows.reverse()
    features = calculate_features(rows)
    quality = Decimal(str(features["data_quality_score"]))
    if quality < min_quality or features["regime"] == "unknown":
        return []
    ret = features["return_5"]
    if ret is None:
        return []
    volume_change = features["volume_change"]
    direction = "LONG" if Decimal(str(ret)) > Decimal("0.02") else "SHORT" if Decimal(str(ret)) < Decimal("-0.02") else "NONE"
    if direction == "NONE":
        return []
    strategy_id = "momentum_breakout_v1"
    score = min(Decimal("1"), abs(Decimal(str(ret))) * Decimal("5"))
    if volume_change is not None and Decimal(str(volume_change)) > Decimal("0.5"):
        score = min(Decimal("1"), score + Decimal("0.1"))
    score = score.quantize(Decimal("0.000001"))
    decision = "CANDIDATE" if score >= Decimal("0.60") and quality >= min_quality else "NO_ACTION"
    evidence: dict[str, Any] = {"return_5": str(ret), "volume_change": None if volume_change is None else str(volume_change),
        "trend": features["trend"], "regime": features["regime"], "data_quality_score": str(quality),
        "last_observed_at": features["last_observed_at"].isoformat(), "execution_enabled": False}
    fingerprint = hashlib.sha256(json.dumps([symbol, strategy_id, direction, evidence["last_observed_at"]], separators=(",", ":")).encode()).hexdigest()
    existing = session.scalar(select(DiscoveryCandidate).where(DiscoveryCandidate.fingerprint == fingerprint))
    if existing:
        return [existing]
    candidate = DiscoveryCandidate(fingerprint=fingerprint, symbol=symbol, strategy_id=strategy_id, direction=direction,
        regime=str(features["regime"]), score=score, evidence=evidence, decision=decision)
    session.add(candidate)
    session.commit()
    session.refresh(candidate)
    return [candidate]
