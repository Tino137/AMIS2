from __future__ import annotations

from decimal import Decimal
from statistics import pstdev
from typing import Sequence

from .market_models import MarketObservation


def calculate_features(rows: Sequence[MarketObservation]) -> dict[str, object]:
    if not rows:
        raise ValueError("at least one observation is required")
    ordered = sorted(rows, key=lambda row: row.observed_at)
    closes = [Decimal(row.close) for row in ordered]
    volumes = [Decimal(row.volume) for row in ordered]
    returns = [(closes[i] / closes[i - 1]) - Decimal("1") for i in range(1, len(closes))]
    avg_volume = sum(volumes, Decimal("0")) / Decimal(len(volumes))
    volume_change = None if len(volumes) < 2 or volumes[-2] == 0 else volumes[-1] / volumes[-2] - Decimal("1")
    return_1 = returns[-1] if returns else None
    return_5 = closes[-1] / closes[-6] - Decimal("1") if len(closes) >= 6 else None
    volatility = Decimal(str(pstdev([float(value) for value in returns]))) if len(returns) >= 2 else None
    trend = "unknown"
    if len(closes) >= 3:
        if closes[-1] > closes[0]: trend = "uptrend"
        elif closes[-1] < closes[0]: trend = "downtrend"
        else: trend = "flat"
    quality = sum((Decimal(row.quality_score) for row in ordered), Decimal("0")) / Decimal(len(ordered))
    flags = sorted({flag for row in ordered for flag in (row.quality_flags or [])})
    return {"symbol": ordered[-1].symbol, "count": len(ordered), "last_observed_at": ordered[-1].observed_at,
        "last_close": closes[-1], "return_1": return_1, "return_5": return_5,
        "volatility": volatility, "average_volume": avg_volume, "volume_change": volume_change,
        "trend": trend, "regime": classify_regime(returns, trend, quality),
        "data_quality_score": quality, "quality_flags": flags}


def classify_regime(returns: Sequence[Decimal], trend: str, quality: Decimal) -> str:
    if quality < Decimal("0.90") or len(returns) < 2:
        return "unknown"
    volatility = Decimal(str(pstdev([float(value) for value in returns])))
    if volatility >= Decimal("0.05"):
        return "high_volatility"
    if trend in {"uptrend", "downtrend"}:
        return "trending"
    return "range_bound"
