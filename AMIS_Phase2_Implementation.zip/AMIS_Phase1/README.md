# AMIS — Phase 2 Market Intelligence Foundation

AMIS (Autonomous Market & Intelligence System) Phase 2 extends Phase 1 with provider-neutral OHLCV ingestion, data-quality scoring, deterministic market features, market-regime classification, and persisted opportunity-discovery candidates. It remains a **research and screening system**: it does not execute trades, connect wallets, or transfer funds.

## Scope and assumptions

- Python 3.12 or 3.13.
- SQLite for local development and automated tests; PostgreSQL 17 is the target multi-process deployment database.
- No external service is required for local operation. CSV ingestion uses a real local file. REST ingestion requires an operator-supplied HTTPS provider endpoint and optional token.
- Phase 1 opportunity endpoints, authentication, rate limiting, EV scoring, and risk screening remain available.
- Candidate scores are deterministic heuristic ranks, not calibrated success probabilities or claims of profitability.

## Architecture

```text
CSV / HTTPS REST provider / authenticated API
                    |
                    v
         Schema + OHLCV validation
                    |
                    v
     Quality flags + duplicate-safe persistence
                    |
                    v
   Features -> regime classifier -> discovery rule
                    |
                    v
     Persisted candidate + evidence snapshot

Phase 1 opportunity API -> EV/composite scoring -> risk gate
```

See `docs/phase2-architecture.md` for API contracts, boundaries, and strategy details.

## Clean installation

```bash
python3 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e '.[test]'
cp .env.example .env
```

Set `AMIS_API_KEY` in `.env` to a private random value before exposing the API. Never commit `.env`. For PostgreSQL, install `python -m pip install -e '.[test,postgres]'` and set `AMIS_DATABASE_URL` to the deployment DSN. Keep database credentials in environment/secret-manager configuration, not source files.

## Migrate, test, run

```bash
AMIS_ENV=development AMIS_DATABASE_URL=sqlite:///./amis.db AMIS_API_KEY='replace-with-a-private-random-secret' PYTHONPATH=src python -m alembic upgrade head
PYTHONPATH=src pytest -q
PYTHONPATH=src python -m compileall -q src tests migrations
AMIS_ENV=development AMIS_DATABASE_URL=sqlite:///./amis.db AMIS_API_KEY='replace-with-a-private-random-secret' PYTHONPATH=src python -m uvicorn amis.api:app --host 127.0.0.1 --port 8000
```

Verify `curl http://127.0.0.1:8000/health`. Authenticated endpoints require header `X-AMIS-API-Key`. OpenAPI is at `/openapi.json`.

## Phase 2 API

- `POST /v1/market/observations` — ingest 1–5,000 validated observations per request. Each observation contains `source`, `symbol`, timezone-aware `observed_at`, `open`, `high`, `low`, `close`, and `volume`.
- `GET /v1/market/{symbol}/features` — returns returns, volatility, average volume, volume change, trend, regime, and aggregate quality.
- `POST /v1/discovery/{symbol}` — evaluates available history and returns an idempotent candidate when a supported signal exists; otherwise returns an empty list.
- `GET /v1/discovery?limit=50&offset=0` — list persisted discovery candidates.

Example request shape:

```json
{
  "observations": [
    {
      "source": "manual-feed",
      "symbol": "BTC-USD",
      "observed_at": "2026-10-08T06:00:00Z",
      "open": "60000",
      "high": "60500",
      "low": "59800",
      "close": "60300",
      "volume": "125.5"
    }
  ]
}
```

The example shows the API contract only; no live provider or real market data is bundled. `src/amis/market_data.py` contains working CSV and HTTPS JSON adapters for integration by the operator.

## Verification and limitations

Run `docs/phase2-testing.md` for the complete commands. The current execution environment can run the Python tests and SQLite migrations. Ruff, Mypy, pip-audit, Docker, and PostgreSQL verification must be performed in an environment where those tools and services are available; a SQLite test is not proof of PostgreSQL readiness. The API rate limiter is process-local and requires a shared limiter before horizontally scaled public deployment. Discovery outputs are not trading instructions and have no execution adapter.
