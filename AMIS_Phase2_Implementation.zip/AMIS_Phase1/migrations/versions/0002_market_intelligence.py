"""Add market observations and discovery candidates.

Revision ID: 0002_market_intelligence
Revises: 0001_initial
"""
from alembic import op
import sqlalchemy as sa

revision = "0002_market_intelligence"
down_revision = "0001_initial"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table("market_observations",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("source", sa.String(120), nullable=False),
        sa.Column("symbol", sa.String(80), nullable=False),
        sa.Column("observed_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("open", sa.Numeric(24, 10), nullable=False),
        sa.Column("high", sa.Numeric(24, 10), nullable=False),
        sa.Column("low", sa.Numeric(24, 10), nullable=False),
        sa.Column("close", sa.Numeric(24, 10), nullable=False),
        sa.Column("volume", sa.Numeric(28, 10), nullable=False),
        sa.Column("quality_score", sa.Numeric(8, 6), nullable=False),
        sa.Column("quality_flags", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.UniqueConstraint("source", "symbol", "observed_at", name="uq_observation_source_symbol_time"))
    op.create_index("ix_observation_symbol_time", "market_observations", ["symbol", "observed_at"])
    op.create_table("discovery_candidates",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("fingerprint", sa.String(64), nullable=False),
        sa.Column("symbol", sa.String(80), nullable=False),
        sa.Column("strategy_id", sa.String(80), nullable=False),
        sa.Column("direction", sa.String(12), nullable=False),
        sa.Column("regime", sa.String(40), nullable=False),
        sa.Column("score", sa.Numeric(8, 6), nullable=False),
        sa.Column("evidence", sa.JSON(), nullable=False),
        sa.Column("decision", sa.String(32), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.UniqueConstraint("fingerprint", name="uq_discovery_fingerprint"))
    op.create_index("ix_discovery_symbol_created", "discovery_candidates", ["symbol", "created_at"])


def downgrade() -> None:
    op.drop_index("ix_discovery_symbol_created", table_name="discovery_candidates")
    op.drop_table("discovery_candidates")
    op.drop_index("ix_observation_symbol_time", table_name="market_observations")
    op.drop_table("market_observations")
