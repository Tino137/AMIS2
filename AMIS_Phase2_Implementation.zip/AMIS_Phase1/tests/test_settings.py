import pytest

from amis.settings import get_settings


def test_production_rejects_common_api_key_placeholders(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AMIS_ENV", "production")
    monkeypatch.setenv("AMIS_API_KEY", "replace-with-a-unique-random-secret-at-least-16-chars")
    get_settings.cache_clear()
    try:
        with pytest.raises(ValueError, match="unique secret"):
            get_settings()
    finally:
        get_settings.cache_clear()


def test_production_accepts_non_placeholder_api_key(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AMIS_ENV", "production")
    monkeypatch.setenv("AMIS_API_KEY", "7f2b9a1c4d6e8f0a3b5c7d9e1f2a4b6c")
    get_settings.cache_clear()
    try:
        assert get_settings().environment == "production"
    finally:
        get_settings.cache_clear()
