
import pytest

from amis.schemas import OpportunityCreate


def base_payload() -> dict[str, object]:
    return {
        "domain": "commercial", "title": "Failure test", "description": "Sufficiently detailed test description.",
        "asset_or_counterparty": "Counterparty", "capital_required": "1000", "potential_profit": "200",
        "probability_success": "0.8", "probability_failure": "0.2", "failure_loss": "10",
        "execution_cost": "5", "time_to_completion_hours": "24", "liquidity_score": "0.8",
        "evidence_score": "0.8", "risk_score": "0.2", "execution_complexity_score": "0.2",
        "confidence_score": "0.8", "data_quality_score": "0.95",
    }


def test_negative_capital_is_rejected() -> None:
    data = base_payload()
    data["capital_required"] = "-1"
    with pytest.raises(ValueError):
        OpportunityCreate(**data)


def test_probability_out_of_range_is_rejected() -> None:
    data = base_payload()
    data["probability_success"] = "1.1"
    data["probability_failure"] = "-0.1"
    with pytest.raises(ValueError):
        OpportunityCreate(**data)


def test_unknown_fields_are_rejected() -> None:
    data = base_payload()
    data["unexpected"] = "attack-surface"
    with pytest.raises(ValueError):
        OpportunityCreate(**data)
