from __future__ import annotations

from datetime import datetime, timedelta, timezone
from decimal import Decimal

from fastapi.testclient import TestClient
from sqlalchemy import select

from amis.api import app
from amis.db import SessionLocal
from amis.market_models import MarketObservation

API_HEADERS = {"X-AMIS-API-Key": "test-api-key-1234567890"}


def bars(symbol: str = "TEST-USD", count: int = 8) -> list[dict[str, object]]:
    now = datetime.now(timezone.utc).replace(microsecond=0)
    result = []
    for index in range(count):
        price = Decimal("100") + Decimal(index * 2)
        result.append({
            "source": "unit-test", "symbol": symbol,
            "observed_at": (now - timedelta(minutes=(count-index)*5)).isoformat(),
            "open": str(price), "high": str(price + Decimal("1")),
            "low": str(price - Decimal("1")), "close": str(price), "volume": str(100 + index * 100),
        })
    return result


def test_market_ingest_features_and_discovery_workflow() -> None:
    with TestClient(app) as client:
        response = client.post("/v1/market/observations", json={"observations": bars()}, headers=API_HEADERS)
        assert response.status_code == 200, response.text
        assert response.json()["accepted"] == 8
        features = client.get("/v1/market/TEST-USD/features", headers=API_HEADERS)
        assert features.status_code == 200, features.text
        assert features.json()["trend"] == "uptrend"
        assert features.json()["regime"] == "trending"
        assert Decimal(features.json()["return_5"]) > Decimal("0")
        discovery = client.post("/v1/discovery/TEST-USD", headers=API_HEADERS)
        assert discovery.status_code == 200, discovery.text
        assert len(discovery.json()) == 1
        candidate = discovery.json()[0]
        assert candidate["direction"] == "LONG"
        assert candidate["decision"] in {"CANDIDATE", "NO_ACTION"}
        assert candidate["evidence"]["execution_enabled"] is False
        repeated = client.post("/v1/discovery/TEST-USD", headers=API_HEADERS)
        assert repeated.status_code == 200
        assert repeated.json()[0]["id"] == candidate["id"]


def test_ingestion_is_idempotent_for_duplicate_bars() -> None:
    observations = bars(symbol="DUP-USD", count=1)
    with TestClient(app) as client:
        first = client.post("/v1/market/observations", json={"observations": observations}, headers=API_HEADERS)
        second = client.post("/v1/market/observations", json={"observations": observations}, headers=API_HEADERS)
    assert first.status_code == second.status_code == 200
    assert first.json()["accepted"] == 1
    assert second.json()["duplicates"] == 1
    with SessionLocal() as session:
        count = len(list(session.scalars(select(MarketObservation).where(MarketObservation.symbol == "DUP-USD"))))
    assert count == 1


def test_future_timestamp_is_rejected_without_persistence() -> None:
    item = bars(symbol="FUTURE-USD", count=1)[0]
    item["observed_at"] = (datetime.now(timezone.utc) + timedelta(days=1)).isoformat()
    with TestClient(app) as client:
        response = client.post("/v1/market/observations", json={"observations": [item]}, headers=API_HEADERS)
    assert response.status_code == 200
    assert response.json()["rejected_quality"] == 1
    with SessionLocal() as session:
        assert session.scalar(select(MarketObservation.id).where(MarketObservation.symbol == "FUTURE-USD")) is None


def test_market_ingestion_requires_authentication() -> None:
    with TestClient(app) as client:
        response = client.post("/v1/market/observations", json={"observations": bars(count=1)})
    assert response.status_code == 401


def test_bad_ohlc_is_rejected() -> None:
    item = bars(count=1)[0]
    item["high"] = "1"
    with TestClient(app) as client:
        response = client.post("/v1/market/observations", json={"observations": [item]}, headers=API_HEADERS)
    assert response.status_code == 422


def test_features_not_found_is_404() -> None:
    with TestClient(app) as client:
        response = client.get("/v1/market/UNKNOWN/features", headers=API_HEADERS)
    assert response.status_code == 404


def test_provider_requires_https() -> None:
    from amis.market_data import JsonRestMarketDataProvider
    import pytest
    with pytest.raises(ValueError, match="HTTPS"):
        JsonRestMarketDataProvider("http://example.invalid/data")


def test_csv_provider_reads_real_csv(tmp_path) -> None:
    from amis.market_data import CsvMarketDataProvider
    csv_path = tmp_path / "market.csv"
    csv_path.write_text("timestamp,symbol,open,high,low,close,volume\n2026-10-08T06:00:00Z,CSV-USD,10,12,9,11,20\n", encoding="utf-8")
    records = CsvMarketDataProvider(csv_path).fetch("CSV-USD")
    assert len(records) == 1
    assert records[0].symbol == "CSV-USD"
    assert records[0].close == Decimal("11")


def test_csv_provider_rejects_missing_columns(tmp_path) -> None:
    from amis.market_data import CsvMarketDataProvider
    import pytest
    csv_path = tmp_path / "invalid.csv"
    csv_path.write_text("timestamp,symbol,close\n", encoding="utf-8")
    with pytest.raises(ValueError, match="must contain"):
        CsvMarketDataProvider(csv_path).fetch("CSV-USD")


def test_rest_provider_rejects_invalid_response_record(monkeypatch) -> None:
    import json
    import pytest
    from amis.market_data import JsonRestMarketDataProvider

    class FakeResponse:
        status = 200
        def __enter__(self): return self
        def __exit__(self, *args): return False
        def read(self, limit: int) -> bytes: return json.dumps([{"timestamp": "2026-10-08T06:00:00Z", "close": "1"}]).encode()

    monkeypatch.setattr("urllib.request.urlopen", lambda *args, **kwargs: FakeResponse())
    provider = JsonRestMarketDataProvider("https://feed.example.test/ohlcv")
    with pytest.raises(ValueError, match="invalid OHLCV"):
        provider.fetch("TEST-USD")
