import os
import subprocess
import sys
from pathlib import Path


def _env() -> dict[str, str]:
    env = os.environ.copy()
    env["AMIS_DATABASE_URL"] = "sqlite:///./migration_test.db"
    env["AMIS_ENV"] = "test"
    env["AMIS_API_KEY"] = "test-api-key-1234567890"
    return env


def test_migration_head_is_defined() -> None:
    result = subprocess.run(
        [sys.executable, "-m", "alembic", "heads"],
        cwd=Path(__file__).resolve().parents[1],
        env=_env(),
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0
    assert "0002_market_intelligence" in result.stdout


def test_migration_upgrade_and_current() -> None:
    db = Path("migration_test.db")
    db.unlink(missing_ok=True)
    upgrade = subprocess.run(
        [sys.executable, "-m", "alembic", "upgrade", "head"],
        cwd=Path(__file__).resolve().parents[1],
        env=_env(),
        capture_output=True,
        text=True,
        check=False,
    )
    assert upgrade.returncode == 0, upgrade.stderr

    current = subprocess.run(
        [sys.executable, "-m", "alembic", "current"],
        cwd=Path(__file__).resolve().parents[1],
        env=_env(),
        capture_output=True,
        text=True,
        check=False,
    )
    assert current.returncode == 0
    assert "0002_market_intelligence" in current.stdout
    db.unlink(missing_ok=True)


def test_postgresql_migration_sql_can_be_generated_without_driver() -> None:
    env = _env()
    env["AMIS_DATABASE_URL"] = (
        "postgresql+psycopg://amis_ci:amis_ci_password@localhost:5432/amis_ci"
    )
    result = subprocess.run(
        [sys.executable, "-m", "alembic", "upgrade", "head", "--sql"],
        cwd=Path(__file__).resolve().parents[1],
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0, result.stderr
    assert 'CREATE TABLE market_observations' in result.stdout
    assert 'CREATE TABLE discovery_candidates' in result.stdout
    assert 'CREATE TABLE opportunities' in result.stdout
