"""PostgreSQL integration checks, enabled when AMIS_TEST_POSTGRES_URL is set."""

from __future__ import annotations

import os
import uuid
from datetime import datetime, timedelta, timezone
from decimal import Decimal

import pytest
from sqlalchemy import delete, inspect, select
from sqlalchemy.orm import Session, sessionmaker

from amis.discovery import discover_candidates
from amis.market_models import DiscoveryCandidate, MarketObservation
from amis.market_schemas import ObservationBatch, ObservationInput
from amis.market_service import ingest_observations


POSTGRES_URL = os.getenv("AMIS_TEST_POSTGRES_URL")
pytestmark = pytest.mark.skipif(
    not POSTGRES_URL,
    reason="AMIS_TEST_POSTGRES_URL is not configured; PostgreSQL integration test skipped",
)


def test_postgres_schema_ingestion_idempotency_and_discovery() -> None:
    """Exercise PostgreSQL migrations, Numeric/JSON types, and service behavior."""
    from sqlalchemy import create_engine

    assert POSTGRES_URL is not None
    engine = create_engine(POSTGRES_URL, pool_pre_ping=True)
    symbol = f"PGTEST-{uuid.uuid4().hex[:12]}"
    session_factory = sessionmaker(bind=engine, expire_on_commit=False)
    try:
        table_names = set(inspect(engine).get_table_names())
        assert {"alembic_version", "market_observations", "discovery_candidates"} <= table_names

        now = datetime.now(timezone.utc).replace(microsecond=0)
        observations = []
        for index in range(8):
            close = Decimal("100") + Decimal(index * 3)
            observations.append(
                ObservationInput(
                    source="postgres-integration-test",
                    symbol=symbol,
                    observed_at=now - timedelta(minutes=(8 - index) * 5),
                    open=close,
                    high=close + Decimal("1"),
                    low=close - Decimal("1"),
                    close=close,
                    volume=Decimal(100 + index * 100),
                )
            )

        with session_factory() as session:
            result = ingest_observations(session, ObservationBatch(observations=observations))
            assert result.accepted == 8
            assert result.duplicates == 0

        with session_factory() as session:
            duplicate_result = ingest_observations(
                session, ObservationBatch(observations=observations)
            )
            assert duplicate_result.accepted == 0
            assert duplicate_result.duplicates == 8
            candidates = discover_candidates(session, symbol)
            assert candidates
            assert candidates[0].evidence["execution_enabled"] is False
            assert session.scalar(
                select(MarketObservation.id).where(MarketObservation.symbol == symbol)
            ) is not None

    finally:
        with Session(engine) as session:
            candidate_ids = select(DiscoveryCandidate.id).where(
                DiscoveryCandidate.symbol == symbol
            )
            session.execute(delete(DiscoveryCandidate).where(DiscoveryCandidate.id.in_(candidate_ids)))
            session.execute(delete(MarketObservation).where(MarketObservation.symbol == symbol))
            session.commit()
        engine.dispose()
