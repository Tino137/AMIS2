# Phase 2 Failure-Mode Analysis

| Failure mode | Cause | Probability | Impact | Detection | Mitigation | Recovery |
|---|---|---:|---:|---|---|---|
| Malformed bars | Provider schema drift or bad payload | Medium | High | Pydantic 422 / provider validation error | Strict schemas and OHLC invariants | Fix source record and retry |
| Duplicate bar | Retries or provider overlap | High | Medium | Unique source/symbol/time key | Idempotent duplicate handling | Re-submit safely |
| Concurrent duplicate race | Two ingestion workers insert same key | Low/Medium | Medium | DB unique constraint | Savepoint and unique constraint | Treat existing record as duplicate |
| Stale feed | Provider outage or delayed data | Medium | High | Quality flags and score | Quality threshold blocks discovery | Restore feed and ingest fresh bars |
| Future timestamp | Clock drift/provider bug | Low | High | Timestamp validation and quality check | Reject record | Correct provider clock and retry |
| Provider unavailable | Network outage, 429, timeout | Medium | Medium/High | Bounded adapter exceptions | HTTPS, bounded timeout, explicit errors | Retry with operator-controlled backoff |
| Invalid provider response | HTML/error body or unexpected JSON | Medium | High | JSON/shape validation | Reject malformed response | Investigate provider and retry |
| DB unavailable | Database/network failure | Low/Medium | High | SQLAlchemy exception / health endpoint | Transactional persistence, health checks | Restore DB; retry idempotently |
| Weak/no signal | Insufficient history or low quality | High | Low | Empty discovery result / unknown regime | Fail closed; no candidate | Ingest sufficient quality history |
| False-positive heuristic | Overfit rule/regime | Medium | High | Out-of-sample monitoring (future phase) | Candidate-only, no execution | Disable strategy and review |
| Token exposure | Misconfigured deployment | Low | Critical | Secret scanning and access review | Env/secret manager; no token logs | Rotate credential, audit access |
