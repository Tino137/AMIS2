# Phase 2 Test and Verification Guide

Run from the repository root:

```bash
python -m pip install -e '.[test]'
PYTHONPATH=src pytest -q
python -m compileall -q src tests migrations
AMIS_ENV=test AMIS_DATABASE_URL=sqlite:///./migration_test.db AMIS_API_KEY=test-api-key-1234567890 PYTHONPATH=src python -m alembic upgrade head
AMIS_ENV=test AMIS_DATABASE_URL=sqlite:///./migration_test.db AMIS_API_KEY=test-api-key-1234567890 PYTHONPATH=src python -m alembic current
```

Tests cover Phase 1 opportunity API regression, API authentication, schema rejection, duplicate ingestion, OHLC validation, future timestamp rejection, feature generation, trend/regime classification, discovery idempotency, REST provider HTTPS enforcement, SQLite migration head/current, and PostgreSQL-dialect offline migration generation. `tests/test_postgres_integration.py` additionally verifies migrated schema, numeric/JSON persistence, duplicate-safe ingestion, and discovery when `AMIS_TEST_POSTGRES_URL` points to a migrated PostgreSQL test database. Test database data is not production data.

For the complete gate, install `.[test,dev,postgres]` and run `ruff check .`, `ruff format --check .`, `mypy src`, and `pip-audit`. The GitHub Actions workflow runs these checks, performs Alembic migrations against both SQLite and an actual PostgreSQL service, and runs the PostgreSQL service-level integration test after migrations. This sandbox has no DNS/network access for installing missing tools and has no Docker/PostgreSQL binaries, so those gates cannot be executed locally here. Do not treat the local SQLite pass as evidence that PostgreSQL or container runtime behavior has passed; the CI run must be green.
