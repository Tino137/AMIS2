# AMIS Phase 2 — Market Intelligence and Opportunity Discovery

## Scope and assumptions

Phase 2 extends Phase 1's authenticated FastAPI service and SQLAlchemy persistence. It provides provider-neutral OHLCV ingestion, data-quality annotation, deterministic market features, a transparent regime classifier, and a conservative discovery candidate generator. It does not place orders, connect wallets, allocate capital, or claim profitability. A discovery candidate is research output only (`execution_enabled=false`).

Python 3.12/3.13 are supported by the package metadata. Existing Phase 1 environment variables and risk configuration remain in force. SQLite is suitable for local development/testing; PostgreSQL is the intended multi-process deployment database. No external API is required for local operation. REST ingestion requires an operator-supplied HTTPS endpoint and optional bearer token. Do not store real tokens in YAML, source control, or logs.

## Components and flow

1. `market_data.py`: `MarketDataProvider` protocol plus real CSV and HTTPS JSON adapters.
2. `market_schemas.py`: strict input validation, timezone enforcement, OHLCV invariants, and bounded batch sizes.
3. `market_quality.py`: stale/future/zero-volume/extreme-range checks and a transparent quality score.
4. `market_service.py`: idempotent observation ingestion and duplicate accounting.
5. `market_models.py`: persistent observations and discovery candidates, unique constraints, and indexes.
6. `features.py`: return, realized population volatility, average volume, volume change, trend, and regime calculations.
7. `discovery.py`: versioned momentum candidate rule, evidence snapshot, quality gate, fingerprint-based idempotency. No execution path exists.
8. `api.py`: authenticated, rate-limited endpoints and response validation.
9. Alembic revision `0002_market_intelligence`: additive schema migration over Phase 1 revision `0001_initial`.

Flow: provider or authenticated caller → schema validation → quality annotation → unique-constraint-backed persistence → features → regime → discovery candidate → audit-friendly evidence record. Invalid payloads return HTTP 422; unknown symbols return HTTP 404; unauthenticated requests return HTTP 401; database health failure returns HTTP 503. Duplicate bars are reported, not duplicated.

## API contracts

- `POST /v1/market/observations`: `{ "observations": [ { "source", "symbol", "observed_at", "open", "high", "low", "close", "volume" } ] }`; maximum 5,000 observations. Returns accepted, duplicates, rejected_quality, and stored IDs.
- `GET /v1/market/{symbol}/features`: features over at most the 5,000 earliest matching stored observations (the query is currently ordered ascending); returns 404 when none exist.
- `POST /v1/discovery/{symbol}`: evaluates stored observations and returns the matching idempotent candidate, or an empty list if insufficient/low-quality data or no signal.
- `GET /v1/discovery?limit=50&offset=0`: paginated persisted candidates.

All non-health endpoints require `X-AMIS-API-Key` and pass through the Phase 1 rate limiter. OpenAPI is available at `/openapi.json` in the running service.

## Strategy interpretation and limits

`momentum_breakout_v1` uses a 5-observation return threshold of ±2%, adds a bounded score increment for volume growth above 50%, and requires a quality score of at least 0.90. The score is a heuristic prioritization metric, not a calibrated probability. Regime classification is deterministic and uses available history; fewer than three closes or inadequate quality produces `unknown`. It must be evaluated out-of-sample before any capital deployment.

## Storage and operational notes

Revision `0002_market_intelligence` adds `market_observations` and `discovery_candidates`, with uniqueness constraints to prevent duplicate source/symbol/time observations and duplicate candidate fingerprints. Back up the database before migrations. Keep migration backups and test restores before production changes. For PostgreSQL, configure `AMIS_DATABASE_URL` and install the optional `postgres` dependency group.

## Security boundaries

Input schemas reject extra fields, invalid symbols, naive timestamps, non-positive OHLC prices, inconsistent OHLC ranges, and oversized batches. REST adapters require HTTPS, enforce a bounded timeout, bound response size, and do not log tokens. API endpoints inherit Phase 1 API-key authentication and rate limiting. There is no broker/wallet credential or order execution integration in Phase 2.
