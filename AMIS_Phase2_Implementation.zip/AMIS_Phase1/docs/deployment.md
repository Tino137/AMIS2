# Deployment

## Local / development

Use SQLite and run Alembic migrations before starting the API.

## Production

Use PostgreSQL and set `AMIS_DATABASE_URL` to a `postgresql+psycopg://...` URL. Install the optional PostgreSQL dependency with:

```bash
python -m pip install -e '.[postgres]'
```

Run migrations:

```bash
python -m alembic upgrade head
```

Start:

```bash
uvicorn amis.api:app --host 0.0.0.0 --port 8000
```

Use a secrets manager or orchestrator secret mechanism for `AMIS_API_KEY`; do not put production credentials in Compose files, images, or Git.

The included Dockerfile/Compose definition is a deployment template. Container execution was not verified in this environment because Docker is unavailable.

### Docker Compose with PostgreSQL

1. Copy `.env.example` to `.env`.
2. Replace `POSTGRES_PASSWORD` and `AMIS_API_KEY` with unique secrets. Do not commit `.env`.
3. Start with `docker compose up --build -d`. The API image installs the `postgres` extra, including the psycopg driver.
4. Check `docker compose ps` and `docker compose logs api`.

Compose binds the API and database ports to loopback by default. Put a properly configured reverse proxy and TLS termination in front before remote access. These local Compose defaults are not a complete production deployment or secret-management solution.
