# Phase 2 Requirements Traceability

| ID | Requirement | Implementation | Test | Status |
|---|---|---|---|---|
| P2-01 | Provider-neutral market data interface | `src/amis/market_data.py` | provider HTTPS test; CSV adapter tests | Implemented |
| P2-02 | Strict OHLCV validation | `market_schemas.py` | malformed OHLC API test | Implemented |
| P2-03 | Batch bounds and timezone validation | `market_schemas.py` | API validation | Implemented |
| P2-04 | Persistent market observations | `market_models.py`, migration 0002 | ingest/persistence tests | Implemented |
| P2-05 | Duplicate-safe ingestion | `market_service.py`, DB unique constraint | duplicate ingestion test | Implemented |
| P2-06 | Data quality metadata | `market_quality.py` | future timestamp rejection test | Implemented |
| P2-07 | Return/volatility/volume features | `features.py` | market workflow test | Implemented |
| P2-08 | Market regime classification | `features.py` | trending regime test | Implemented |
| P2-09 | Evidence-backed discovery candidate | `discovery.py` | workflow/idempotency test | Implemented |
| P2-10 | Authenticated/rate-limited API | `api.py`, Phase 1 auth | auth regression tests | Implemented |
| P2-11 | Additive database migration | `migrations/versions/0002_market_intelligence.py` | Alembic head/current tests | Implemented |
| P2-12 | No production trade execution | Discovery evidence sets execution disabled; no order client | assertion in workflow test | Implemented |
| P2-13 | Operational/security documentation | `docs/phase2-*` | manual document review | Documented |
| P2-14 | Ruff/Mypy/dependency audit | CI/operator tooling | CI lint/type/audit steps | BLOCKED until executed in equipped CI; package installation is blocked by unavailable DNS in this sandbox |
| P2-15 | PostgreSQL/Docker runtime | Dockerfile installs `.[postgres]`; Compose requires non-placeholder secrets and binds ports to loopback; CI includes PostgreSQL migrations and service-level integration tests | PostgreSQL integration test plus actual CI service | Configured; local runtime remains unverified until CI or an equipped host passes |
| P2-16 | Production configuration safety | `settings.py` validates `AMIS_ENV` and rejects common placeholder API keys in production | `tests/test_settings.py` | Implemented and tested |
